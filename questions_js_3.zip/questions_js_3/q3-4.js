"use strict";

const zipcloudURL = "https://zipcloud.ibsnet.co.jp/api/search?zipcode=";

const button = document.getElementById('form_button');

const addressShow = document.getElementById('address_show');

const options = {
    timeout: 10000
};

const errorMessage = document.getElementById("error_message");

const postalNumber = document.getElementById('postcode_input').value;

button.addEventListener('click',()=>{
    if(postalNumber.length === 7){
        
        const searchURL = zipcloudURL + postalNumber;
        console.log(postalNumber);
        console.log(searchURL);
        addressShow.textContent = postalNumber;
    
        fetch(searchURL, options)
        .then( response => response.json())
        .then( response2 => {
            console.log(response2.results[0].address1);
            const fullAddress = response2.results[0].address1 + response2.results[0].address2 + response2.results[0].address3;
            address_input.value = fullAddress;
        }).catch(e=>console.log("エラー：", e.message))
    } else if (postalNumber.length !== 7){
        errorMessage.textContent = "7桁の数字をハイフン無しで入力してください";
    }
})

